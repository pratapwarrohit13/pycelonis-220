"""Module contains all utility functions used in PyCelonis."""

