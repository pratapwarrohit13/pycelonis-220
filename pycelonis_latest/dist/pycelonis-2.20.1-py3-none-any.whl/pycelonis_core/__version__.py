"""Module contains current package version."""

__version__ = "2.10.3"
