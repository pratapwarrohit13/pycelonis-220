"""Module for base data classes used within PyCelonis."""
