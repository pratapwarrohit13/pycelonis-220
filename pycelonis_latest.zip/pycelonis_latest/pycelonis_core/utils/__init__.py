"""Module for pycelonis core utility functions."""
