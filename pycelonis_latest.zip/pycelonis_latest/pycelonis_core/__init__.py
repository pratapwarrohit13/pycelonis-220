"""Module to allow communication with low-level APIs."""
